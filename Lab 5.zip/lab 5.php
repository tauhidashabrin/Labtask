<html>
<head>
<style>
.error {color: red;}
</style>
</head>

<body>
<?php
$nameErr=$emailErr=$usernameErr=$passwordErr=$confirmpasswordErr=$genderErr=$ddErr=$mmErr=$yyyyErr="";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["name"])) {
    $nameErr= "Name is required";
  } elseif(!preg_match("/^[A-Za-z][A-Za-z0-9 -_]*[A-Za-z0-9 -_]$/",$_POST['name']))
  {
	  $nameErr= "only letters";
  }
  else {
     echo $_POST["name"];
  }
  
  
  if (empty($_POST["email"])) {
    $emailErr= "Email is required";
  }
else
   if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
     $emailErr= "Invalid email format!!!";  
      

		
}  
  else {
    echo $_POST["email"];
  }
    
  if (empty($_POST["username"])) {
    $usernameErr= "username required";
  } else {
    echo $_POST["username"];
  }

  if (empty($_POST["password"])) {
    $passwordErr= "give a password";
  } elseif( !preg_match( "/[^A-Za-z0-9]$/", $_POST['password'] || strlen( $_POST['password']) < 8))
        {
			$passwordErr= "Invalid password!";
		}
  
  else {
    echo $_POST["password"];
  }
  if (empty($_POST["confirmpassword"])) {
    $confirmpasswordErr= "confirm the password";
  } else {
    echo $_POST["confirmpassword"];
  }

  if (empty($_POST["gender"])) {
    $genderErr= "Gender is required";
  } else {
    echo $_POST["gender"];
  }
  
 if (empty($_POST['dd'])|| empty($_POST['mm']) || empty($_POST['yyyy']) ) {
	 
 $ddErr=$mmErr=$yyyyErr="Error! field is empty";}
	else {
	echo $_POST['dd']."/".$_POST['mm']."/".$_POST['yyyy'];
	}
	
 }
 




?>
<fieldset>
    <legend><b>REGISTRATION</b></legend>
	<form action="#" method="POST">
		<br/>
		
		<p><span class="error">* required field.</span></p>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text">
				 <span class="error">* <?php echo $nameErr;?></span>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text">
					 <span class="error">* <?php echo $emailErr;?></span>
					
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>User Name</td>
				<td>:</td>
				<td><input name="userName" type="text">
				 <span class="error">* <?php echo $usernameErr;?></span>
				
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password">
				 <span class="error">* <?php echo $passwordErr;?></span>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="confirmPassword" type="password">
				 <span class="error">* <?php echo $confirmpasswordErr;?></span>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio">Male
						<input name="gender" type="radio">Female
						<input name="gender" type="radio">Other
						 <span class="error">* <?php echo $genderErr;?></span>
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" size="2" />/
						<input type="text" size="2" />/
						<input type="text" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
						
					</fieldset>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input type="submit" value="Submit">
		<input type="reset">
	</form>
</fieldset>
</body>
</html>